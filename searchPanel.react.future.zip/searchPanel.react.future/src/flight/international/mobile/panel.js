import React, { Component } from 'react';

class Panel extends Component {
    render () {
        return (
            <div>
                <p>國際機票Masdsadssa版面板</p>
            
                
            
            </div>
        );
    }
}

export default Panel;