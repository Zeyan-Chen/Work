import React, { Component, PureComponent } from 'react';
// import moment from 'moment';
import StRcln from '../../../../magaele/st_rcln';
import IcRcln from '../../../../magaele/ic_rcln';
import IntRcln from '../../../../magaele/int_rcln';
import IntGpct from '../../../../magaele/int_gpct';
import CyRcln from '../../../../magaele/cy_rcln';
import BtRcnb from '../../../../magaele/bt_rcnb';
import { ClickOutSide } from '../../../../utils';
import NtbRcln,  { Tab } from '../../../../magaele/ntb_rcln';
import StRnls from '../../../../magaele/st_rnls';
import '../../../../magaele/core/core';
import '../css.scss';
import utils from '../../../../utils/utils';


const Country = [
    { text: '台北松山', value: 'TSA' },
    { text: '台東豐年', value: 'TTT' },
    { text: '高雄小港', value: 'KHH' },
    { text: '台中', value: 'RMQ' },
    { text: '花蓮', value: 'HUN' },
    { text: '澎湖馬公', value: 'MZG' },
    { text: '金門', value: 'KNH' }
];

// function arrangeData (data) {
//     console.log('arrangeData');
//     let option = data;
//     let newOption = {};
//     for (let key in option) {
//         if (option['TRIP'] === 1) {
//             if (key !== 'RETURN_DATE') {
//                 newOption[key] = option[key];
//             }
//         } else {
//             newOption[key] = option[key];
//         }
//     }
//     checkData(newOption);
// }

// function checkData (data) {
//     console.log('checkData');
//     let option = data;
//     let checkingOK;
//     console.log('optino', option);
//     for (let key in option) {
//         // console.log(option[key]);
//         if (!option[key]) {
//             console.log('請輸入完整資料');
//             checkingOK = false;
//             break;
//         } else {
//             if (key === 'DEPARTURE_DATE') {
//                 let date = option[key].replace(/\//g, '-');
//                 option[key] = date;
//             }
//             if (key === 'RETURN_DATE') {
//                 let date = option[key].replace(/\//g, '-');
//                 option[key] = date;
//             }
//             checkingOK = true;
//         }
//     }
//     console.log('checkingOK', checkingOK);
//     if (checkingOK) {
//         toQueryString(option);
//     }
// }

// function toQueryString (data) {
//     console.log('toQueryString');
//     console.log(data);
//     let option = data;
//     let string = '';
//     let optionLength = Object.keys(option).length;
//     let i = 0;
//     for (let key in option) {
//         if ((Object.prototype.hasOwnProperty.call(option, key))) {
//             i++;
//             if (i >= optionLength) {
//                 string += key + '=' + option[key];
//             } else {
//                 string += key + '=' + option[key] + '&';
//             }
//         }
//     }
//     window.open('https://twflight.liontravel.com/search?' + string);
//     console.log(string);
// }

// 艙等
const Cabin  = [
    { text: '經濟艙', value: '0' },
    { text: '商務艙', value: '1' },
    { text: '頭等艙', value: '2' },
];

// CustomComponent、ContentComponent 都是人數艙等的
const CustomComponent = (props) => {
    return (
        <IntRcln
            request
            // value="共1人，不限艙等"
            value={`共${props.peopleNumber}人，${[props.cabin]}`}
            label="人數/艙等"
            icon={<IcRcln name="toolstaff" />}
            readOnly
        />
    );
};

// const ContentComponent = (props) => {
//     console.log('number: ', props);
//     let count = props;

//     function onClickAdd (props) {
//         console.log('add');
//     }
//     function onClickMinus (props) {
//         console.log('minus');

//     }
//     return (
//         <React.Fragment>
//             <StRcln
//                 option={Cabin}
//                 placeholder="經濟艙"
//                 label="艙等"
//                 req
//                 whenCloseCallBack={() => console.log('父層whenCloseCallBack')}
//                 onChangeCallBack={(val) => props.selectCabin(val)}
//             />
//             <div className="peopleContent">
//                 <p>人數</p>
//                 <IntGpct
//                     max={10}
//                     min={1}
//                     count={1}
//                     btnClassMinus="ic_rcln toolcancelb"
//                     btnClassAdd="ic_rcln tooladdb"
//                     onClickAdd={onClickAdd} // 按下增加
//                     onClickMinus={onClickMinus} // 按下減少
//                 />
//             </div>
//         </React.Fragment>
//     );
// };

// 單選月曆
class OneChoose extends Component {
    static defaultProps = {
        doubleMonth: false,
    };

    state = {
        selectedStartDate: '',
        startInputValue: '2018-10-17',
        onFocus: false,
    };

    clickDate = (date) => {
        if (this.props.selectDate) {
            this.props.selectDate(date);
        }
        this.setState(prevState => ({
            onFocus: false,
            selectedStartDate: date,
            startInputValue: date,
        }));
    }

    inputChange = (e) => {
        const value = e.target.value;
        this.setState(prevState => ({
            ...prevState,
            startInputValue: value,
        }));
    }

    render () {
        const {
            selectedStartDate,
            startInputValue,
            onFocus,
        } = this.state;

        const {
            doubleMonth,
        } = this.props;

        const style = {
            'borderColor': 'red',
        };

        return (
            <ClickOutSide
                onClickOutside={() => {
                    this.setState(prevState => ({
                        ...prevState,
                        onFocus: false,
                    }));
                }}
            >
                <input
                    type="text"
                    placeholder="選擇日期"
                    value={startInputValue}
                    onFocus={() => { this.setState(prevState => ({
                        ...prevState,
                        onFocus: true,
                    })); }}
                    onChange={this.inputChange}
                    readOnly
                    style={onFocus ? style : null}
                />
                {
                    !onFocus ?
                        null :
                        <CyRcln
                            doubleMonth={doubleMonth}
                            activeStart="2017-12"
                            activeEnd="2019-02"
                            startDate="2018-09-03"
                            endDate="2019-01-20"
                            selectedStartDate={selectedStartDate}
                            onDateClick={this.clickDate}
                        />
                }
            </ClickOutSide>
        );
    }
}

// 主畫面
class Panel extends Component {
    static defaultProps = {
        doubleMonth: false,
    };
    constructor (props) {
        super(props);
        this.state = {
            sFairp: 'XZM',          // 出發地    _XZM_MFM 取前面
            sTairp: 'SHA',          // 目的地
            sFcity: 'MFM',          // 出發地    _XZM_MFM 取後面
            sTcity: 'SHA',          // 目的地
            sFdate: '20181022',     // 出發日期
            sAdt: 1,                // 人
            sChd: 0,
            sClass: 0,              // 艙等
            sTktkind: 'CN',         // 大陸機票種類

            maxPeople: 10,
            items: [],              // AJAX 過來的檔案
            isLoaded: false,        // 如果 Load 好了就 True
            cabinText: '經濟艙',
            max: 10,
            min: 1,
            option: null
        };
    }

    componentDidMount () {
        this.handleServerItemsLoad();
        this.dptOptionLoad();
        utils.fetchJsToObj('../json/GetArrayTkt6.js', (item) => this.getData(item)
        );
    }
    componentDidUpdate () {
        console.log(this.state);
        // console.log('option:', this.state.option);
    }
    getData = (item) => {
        console.log(item);

        let item1 = item.vCityAirportList.filter((tags) => {
            console.log(tags);

            if (tags.fullName.indexOf('中國大陸') !== -1) {
                return true;
            } else {
                return false;
            }
        });
        console.log(item1);
        this.setState({ option: item1 });
    }

    // AJAX 傳過來的資料
    handleServerItemsLoad = () => {
        fetch('../json/twflightdest.json')
            .then((response) => {
                // ok 代表狀態碼在範圍 200-299
                if (!response.ok) throw new Error(response.statusText);
                return response.json();
            })
            .then((itemList) => {
                // console.log('itemlist', itemList);
                // 載入資料，重新渲染
                this.setState({
                    isLoaded: true,
                    items: itemList,
                });
            })
            .catch((error) => {
                // 這裡可以顯示一些訊息
                // console.error(error)
            });
    }

    dptOptionLoad = () => {
        fetch('../json/GetArrayTkt6.js')
            .then((response) => {
                if (!response.ok) throw new Error(response.statusText);
                return response.json();
            }).then((items) => {
                console.log(items);
            });
    }

    // 出發機場
    dptChange (val) {
        this.setState({
            sFairp: val
        });
    }

    // 目的機場
    dtnChange (val) {
        this.setState({
            sTairp: val
        });
    }

    // 出發日期
    selectDate = (date) => {
        console.log(date);
        this.setState({
            sFdate: date
        });
    }

    // 艙等
    selectCabin = (val) => {
        this.setState({
            sClass: val,
            cabinText: Cabin[val].text
        });
    }

    onClickAdd = () => {
        const { sAdt, max } = this.state;
        console.log('add:' + this.state.sAdt);
        let number = sAdt + 1;
        if (number >= max) {
            number = max;
        }
        this.setState({ sAdt: number });
    }

    onClickMinus = () => {
        const { sAdt, min } = this.state;
        console.log('add:' + this.state.sAdt);
        let number = sAdt - 1;
        if (number <= min) {
            number = min;
        }
        this.setState({ sAdt: number });
    }

    // 人數 / 艙等


    // passengerChange (selectValue) {
    //     this.setState({
    //         PASSENGER_NUMBER: selectValue
    //     });
    // }

    // tripChange (target) {
    //     this.setState({
    //         TRIP: target,
    //     });
    // }
    // clearVaule (e) {
    //     this.setState({ DEPARTURE_DATE: '' });
    // }

    // roundDate (e) {
    //     console.log(e);
    //     this.setState({
    //         DEPARTURE_DATE: e.startInputValue,
    //         // RETURN_DATE: e.endInputValue
    //     });
    // }

    // handleSubmit () {
    //     let info = {
    //         'TRIP': this.state.TRIP,
    //         'BOARD_POINT': this.state.BOARD_POINT,
    //         'OFF_POINT': this.state.OFF_POINT,
    //         'DEPARTURE_DATE': this.state.DEPARTURE_DATE,
    //         'RETURN_DATE': this.state.RETURN_DATE,
    //         'PASSENGER_NUMBER': this.state.PASSENGER_NUMBER
    //     };
    //     console.log('submit');
    //     arrangeData(info);
    // }


    render () {
        const {
            TRIP,
            maxPeople
        } = this.state;

        return (
            <React.Fragment>
                <Tab label="大陸國內機票">
                    <div className="flight_chinese">
                        {/* 出發機場 */}
                        <StRcln
                            ClassName="m-b-sm"
                            option={Country}
                            placeholder="請選擇"
                            label="出發機場"
                            icon={<IcRcln name="planeairplane" />}
                            req
                            breakline
                            // whenMouseDown={() => console.log('父層whenMouseDown')}
                            onChangeCallBack={(e) => { this.dptChange(e) }} // 當 input 有 change 時
                            defaultValue={'TSA'}
                        />

                        {/* 目的機場 */}
                        <StRcln
                            ClassName="m-b-sm"
                            option={Country}
                            placeholder="請選擇"
                            label="目的機場"
                            icon={<IcRcln name="toolmap" />}
                            req
                            breakline
                            // whenMouseDown={() => console.log('父層whenMouseDown')}
                            onChangeCallBack={(e) => { this.dtnChange(e) }}
                            defaultValue={'MZG'}
                        />

                        {/* 出發日期 */}
                        <div tabIndex="-1" className="st_rcln m-b-sm dpt">
                            <i className="ic_rcln tooldate"></i>
                            <div className="dropdown-place-holder selected breakline withIcon">
                                <span className="dropdown-label req breakline">出發日期</span>
                                <OneChoose selectDate={this.selectDate} />
                            </div>
                        </div>

                        {/* 人數 / 艙等 */}
                        <StRnls
                            CustomComponent={<CustomComponent cabin={this.state.cabinText} peopleNumber={this.state.sAdt} />}
                            // ContentComponent={<ContentComponent selectCabin={this.selectCabin} peopleNumber={this.state.sAdt} handlePeopleNumber={this.handlePeopleNumber} />}
                            ContentComponent={
                                <React.Fragment>
                                    <StRcln
                                        option={Cabin}
                                        placeholder="經濟艙"
                                        label="艙等"
                                        req
                                        whenCloseCallBack={() => console.log('父層whenCloseCallBack')}
                                        onChangeCallBack={(e) => this.selectCabin(e)}
                                    />
                                    <div className="peopleContent">
                                        <p>人數</p>
                                        <IntGpct
                                            max={this.state.max}
                                            min={this.state.min}
                                            count={this.state.sAdt}
                                            btnClassMinus="ic_rcln toolcancelb"
                                            btnClassAdd="ic_rcln tooladdb"
                                            onClickAdd={this.onClickAdd} // 按下增加
                                            onClickMinus={this.onClickMinus} // 按下減少
                                        />
                                    </div>
                                </React.Fragment>
                            }
                            moduleClassName="StRnls1"
                            whenOpen={e => console.log('Demo Panel Open')}
                            whenClose={e => console.log('Demo Panel Close')}
                        />

                        {/* footer 泡泡框 、 搜尋 */}
                        <div className="footer">
                            <div className="footerInfo">
                                <IcRcln name="toolif" className="p-r-xs" />
                                    注意事項：目前僅華信航空提供線上即時訂購。
                                <a>參考其他航空</a>
                            </div>
                            <BtRcnb
                                radius
                                prop="string"
                                className="h-sm"
                                lg
                                whenClick={() => { this.handleSubmit() }}>
                                        搜尋
                            </BtRcnb>
                        </div>
                    </div>
                </Tab>
            </React.Fragment>
        );
    }
}

export default Panel;