import React, { Component } from 'react';
import TextInput from './TextInput.js';

class App extends Component {
  render() {
    return <TextInput initText="開始輸入文字吧！" />
  }
}

//輸出App元件
export default App;