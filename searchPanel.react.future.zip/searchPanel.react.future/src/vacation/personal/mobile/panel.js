import React, { Component } from 'react';
import IntRcln from '../../../../magaele/int_rcln';
import IcRcln from '../../../../magaele/ic_rcln';
import StRcln from '../../../../magaele/st_rcln';
import CrRcln from '../../../../magaele/cr_rcln';
import NvbRslb from '../../../../magaele/nvb_rslb';
import CyRcmn from '../../../../magaele/cy_rcmn';
import RoomPageContent from './RoomPageContent';

// 動態自由行M版PC版共用css
import '../css.scss';

// 航空公司下拉options
const airLineOptions = [
    {
        text: '不限',
        value: '',
    },
    {
        text: 'BR - 長榮航空',
        value: 'BR',
    },
    {
        text: 'MU - 中國東方航空',
        value: 'MU',
    },
    {
        text: 'DL - 達美航空',
        value: 'DL',
    },
    {
        text: 'HX - 香港航空',
        value: 'HX',
    },
    {
        text: 'CX - 國泰航空',
        value: 'CX',
    },
    {
        text: 'KA - 港龍航空',
        value: 'KA',
    },
    {
        text: 'NH - 全日空航空',
        value: 'NH',
    },
    {
        text: 'OZ - 韓亞航空',
        value: 'OZ',
    },
    {
        text: 'CI - 中華航空',
        value: 'CI',
    },
    {
        text: 'NX - 澳門航空',
        value: 'NX',
    },
    {
        text: 'JL - 日本航空',
        value: 'JL',
    },
];

// 艙等下拉options
const clskdOptions = [
    {
        text: '不限',
        value: 3,
    },
    {
        text: '經濟艙',
        value: 0,
    },
    {
        text: '商務艙',
        value: 1,
    },
    {
        text: '頭等艙',
        value: 2,
    },
];

// 旅遊天數下拉options
const daysOptions = [
    {
        text: '不限',
        value: '',
    },
    {
        text: '2天',
        value: 2,
    },
    {
        text: '3天',
        value: 3,
    },
    {
        text: '4天',
        value: 4,
    },
    {
        text: '5天',
        value: 5,
    },
    {
        text: '6天',
        value: 6,
    },
    {
        text: '7天',
        value: 7,
    },
    {
        text: '8天以上',
        value: 8,
    },
]

const NvbGoBack = ({
    onClick,
}) => (
    <span
        className="nvb_rslb_goBack"
        onClick={onClick}
    >
        <IcRcln name="toolbefore" />
    </span>
);



class Panel extends Component {
    constructor (props) {
        super(props);
        this.state = {
            Departure: '',
            Destination: '',
            roomlist: '',
            roomage: '',
            Days: '',
            Airline: '',
            clskd: '',
            noTrans: false,
            Keywords: '',
            FromDate: '',
            ToDate: '',
            activeInput: null,
            roomListInput: '',
        };
        this.calendar = null;
    }
    showCalendar (target) {
        this.setState(prevState => ({
            ...prevState,
            activeInput: target,
        }));
    }
    showNvbPage (target) {
        this.setState(prevState => ({
            ...prevState,
            activeInput: target,
        }));
    }
    handleClose = () => {
        this.setState({
            activeInput: null,
        });
    }
    handleConfirm = () => {
        const {
            selectedStartDate,
            selectedEndDate,
        } = this.calendar.state;

        this.setState(prevState => ({
            ...prevState,
            FromDate: selectedStartDate,
            ToDate: selectedEndDate,
            activeInput: null,
        }));
    }
    roomPageConfirm = (pageState) => {
        const {
            inputText: roomListInput,
        } = pageState;

        this.setState(prevState => ({
            ...prevState,
            roomListInput,
            activeInput: null,
        }));
    }
    render () {

        const {
            FromDate,
            ToDate,
            activeInput,
            roomListInput,
        } = this.state;
        const showCalendarPage = activeInput === 0 || activeInput === 1;
        const showRoomPage = activeInput === 'roomlist';

        return (
            <div>
                <div className="input_group">
                    <IntRcln
                        placeholder="出發地"
                        label="出發地"
                        breakline
                        request
                        readOnly
                    />
                    <span className="cal_icon">→</span>
                    <IntRcln
                        placeholder="目的地"
                        label="目的地"
                        breakline
                        request
                        readOnly
                    />
                </div>
                <div className="input_group">
                    <IntRcln
                        placeholder="YYYY/MM/DD"
                        label="出發區間"
                        icon={<IcRcln name="tooldate" />}
                        breakline
                        readOnly
                        request
                        onClick={() => { this.showCalendar(0) }}
                        value={FromDate.replace(/\-/g, '/')}
                    />
                    <span className="cal_icon">~</span>
                    <IntRcln
                        placeholder="YYYY/MM/DD"
                        breakline
                        readOnly
                        onClick={() => { this.showCalendar(1) }}
                        value={ToDate.replace(/\-/g, '/')}
                    />
                </div>
                <IntRcln
                    placeholder="共N間，N人"
                    label="間數/人數"
                    breakline
                    readOnly
                    icon={<IcRcln name="toolmember" />}
                    className="m-b-sm"
                    onClick={() => { this.showNvbPage('roomlist') }}
                    value={roomListInput}
                />
                <IntRcln
                    placeholder="請輸入產品名稱、飯店名稱或關鍵字"
                    label="關鍵字"
                    breakline
                    readOnly
                    className="m-b-sm"
                />
                <StRcln
                    option={airLineOptions}
                    placeholder="請選擇"
                    label="航空公司"
                    breakline
                    onChangeCallBack={() => console.log('父層onChangeCallBack')}
                    ClassName="m-b-sm"
                />
                <StRcln
                    option={clskdOptions}
                    placeholder="請選擇"
                    label="艙等"
                    breakline
                    onChangeCallBack={() => console.log('父層onChangeCallBack')}
                    ClassName="m-b-sm"
                />
                <StRcln
                    option={daysOptions}
                    placeholder="請選擇"
                    label="旅遊天數"
                    breakline
                    onChangeCallBack={() => console.log('父層onChangeCallBack')}
                    ClassName="m-b-sm"
                />
                <CrRcln
                    type="checkbox"
                    name="vehicle"
                    value="Car"
                    className=""
                    textContent="直飛(含中停)"
                    defaultChecked
                    whenChange={() => console.log('whenChangeCallBack')}
                />

                <NvbRslb
                    visible={showCalendarPage}
                    direction="right"
                >
                    <NvbGoBack onClick={this.handleClose} />
                    {
                        showCalendarPage && (
                            <CyRcmn
                                doubleChoose
                                selectedStartDate={FromDate}
                                selectedEndDate={ToDate}
                                activeInput={activeInput}
                                startLabelTitle="入住日期"
                                endLabelTitle="退房日期"
                                ref={e => { this.calendar = e }}
                                onClickConfirm={this.handleConfirm}
                                customDiffTxt={diffDate => {
                                    const showTxt = diffDate + 1;
                                    return '共' + showTxt + '天';
                                }}
                            />
                        )
                    }
                </NvbRslb>
                <NvbRslb
                    visible={showRoomPage}
                    direction="right"
                >
                    <NvbGoBack onClick={this.handleClose} />
                    <RoomPageContent onClickConfirm={this.roomPageConfirm} />
                </NvbRslb>
            </div>
        );
    }
}

export default Panel;