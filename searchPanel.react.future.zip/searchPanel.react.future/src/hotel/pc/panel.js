import React, { Component } from 'react';
import classNames from 'classnames';
import styles from './css.scss';
import IntRcln from '../../../magaele/int_rcln';
import IcRcln from '../../../magaele/ic_rcln';
import DtmRcfr from '../../../magaele/dtm_rcfr';
import Calendar from '../../component/ComposeCalendar';
import RoomPageContent from './RoomPageContent';
import CrRcln from '../../../magaele/cr_rcln';


class Panel extends Component {
    constructor (props) {
        super(props);
        this.state = {
            Destination: {},
            // Code: '',
            // Kind: '',
            // Txt: '',
            Rooms: [],
            CheckIn: '',
            CheckOut: '',
            Filter: {
                Allotment: '0'
            },
            selectedData: [],
            focusDestinationState: false,
            roomOptionState: false,
            roomListInput: '',
        };
    }

    onClickItem = (data) => {
        this.setState(prevState => ({
            selectedData: [data],
        }));
    }
    switchDestination = (boolean) => {
        this.setState(prevState => ({
            focusDestinationState: boolean
        }));
    }
    switchRoomOption = (boolean) => {
        this.setState(prevState => ({
            roomOptionState: boolean
        }));
    }

    peopleSum = (pageState) => {
        const {
            inputText: roomListInput,
            Rooms
        } = pageState;
        this.setState({
            roomListInput,
            Rooms
        });
    }
    handleBooking = (pageState) => {
        const {
            selectedStartDate: CheckIn,
            selectedEndDate: CheckOut,
        } = pageState;
        this.setState({
            CheckIn,
            CheckOut,
        });
    }
    handleAllotment = (boolean) => {
        const Filter = JSON.parse(JSON.stringify(this.state.Filter));
        Filter.Allotment = boolean ? '1' : '0';
        this.setState({
            Filter
        });
    }

    render () {
        const classes = classNames.bind(styles)('hotelsRectPC');
        const {
            selectedData,
            focusDestinationState,
            roomListInput,
            roomOptionState
        } = this.state;
        const txt = (selectedData.length > 0) ? selectedData[0].text : '';
        const selected = selectedData.map(v => v.value);
        return (
            <div className={classes}>
                <div className={`${classes}_hotelCont`}>
                    <div className="destination">
                        <IntRcln
                            placeholder="目的地、地標、區域、飯店名稱"
                            label="目的地"
                            icon={<IcRcln name="toolmap" />}
                            value={txt}
                            onClearValue={value => {
                                console.log(value);
                            }}
                            onClick={() => { this.switchDestination(true) }}
                        />
                        <div className={`dtmRcfr ${focusDestinationState ? 'show' : ''}`}>
                            <button className="close_btn" onClick={() => { this.switchDestination(false) }}>X</button>
                            <DtmRcfr
                                levelKey={['inTaiwan', 'vLine', 'vCountry', 'vCity']}
                                onClickItem={this.onClickItem}
                                dataResouce="./json/hotelMenu.json"
                                replaceRegular={/[a-zA-Z\(\)\s]/g}
                                selectedData={selected}
                            />
                        </div>
                    </div>
                    <div className="booking">
                        <Calendar titleTxt={'住房期間'} totleNights={true} onChange={this.handleBooking} />
                    </div>
                    <div className="input_group">
                        <IntRcln
                            placeholder="共1間，2位大人、0位小孩"
                            label="間數/人數"
                            icon={<IcRcln name="toolmember" />}
                            className=""
                            value={roomListInput}
                            onClick={() => { this.switchRoomOption(true) }}
                        />
                        <div className={`stCont ${roomOptionState ? 'show' : ''}`}>
                            <button className="close_btn" onClick={() => { this.switchRoomOption(false) }}></button>
                            <div>
                                <RoomPageContent changeSum={this.peopleSum} />
                                <p style={{ color: '#24a07d' }}>※單次訂購提供相同房型，相同房型不同入住人數依選購的專案售價。</p>
                            </div>
                        </div>
                    </div>
                    <div><CrRcln type="checkbox" whenChange={this.handleAllotment} textContent="顯示可立即確認訂房"></CrRcln></div>
                </div>
            </div>
        );
    }
}

export default Panel;