import React, { Component } from 'react';
import moment from 'moment';
import cx from 'classnames';
import StRcln from '../../../../magaele/st_rcln';
import IcRcln from '../../../../magaele/ic_rcln';
import IntRcln from '../../../../magaele/int_rcln';
import BtRcnb from '../../../../magaele/bt_rcnb';
import NvbRslb from '../../../../magaele/nvb_rslb';
import CyRcmn from '../../../../magaele/cy_rcmn';
import '../../../../magaele/core/core';
import '../css.scss';


const Country = [
    { text: '台北松山', value: 'TSA' },
    { text: '台東豐年', value: 'TTT' },
    { text: '高雄小港', value: 'KHH' },
    { text: '台中', value: 'RMQ' },
    { text: '花蓮', value: 'HUN' },
    { text: '澎湖馬公', value: 'MZG' },
    { text: '金門', value: 'KNH' }
];

const level = [
    { text: '1位', value: '1' },
    { text: '2位', value: '2' },
    { text: '3位', value: '3' },
    { text: '4位', value: '4' }
];


function arrangeData (data) {
    console.log('arrangeData');
    let option = data;
    let newOption = {};
    for (let key in option) {
        if (option['TRIP'] === 1) {
            if (key !== 'RETURN_DATE') {
                newOption[key] = option[key];
            }
        } else {
            newOption[key] = option[key];
        }
    }
    checkData(newOption);
}


function checkData (data) {
    console.log('checkData');
    let option = data;
    let checkingOK;
    for (let key in option) {
        if (!option[key]) {
            console.log('請輸入完整資料');
            checkingOK = false;
            break;
        } else {
            if (key === 'DEPARTURE_DATE') {
                let date = option[key].replace(/\//g, '-');
                option[key] = date;
            }
            if (key === 'RETURN_DATE') {
                let date = option[key].replace(/\//g, '-');
                option[key] = date;
            }
            checkingOK = true;
        }
    }
    console.log('checkingOK', checkingOK);
    if (checkingOK) {
        toQueryString(option);
    }
}

function toQueryString (data) {
    console.log('toQueryString');
    console.log(data);
    let option = data;
    let string = '';
    let optionLength = Object.keys(option).length;
    let i = 0;
    for (let key in option) {
        if ((Object.prototype.hasOwnProperty.call(option, key))) {
            i++;
            if (i >= optionLength) {
                string += key + '=' + option[key];
            } else {
                string += key + '=' + option[key] + '&';
            }
        }
    }
    window.open('https://twflight.liontravel.com/search?' + string);
    console.log(string);
}

class MobileCalendar extends Component {

    showCalendar (target) {
        this.props.showCalendar(target);
    }
    handleClose = () => {
        this.props.showCalendar(null);
    }
    handleConfirm = () => {
        const {
            selectedStartDate,
            selectedEndDate,
        } = this.calendar.state;

        this.props.hadelChangeDate(selectedStartDate, selectedEndDate, null);
    }
    render () {
        const {
            activeInput,
            DEPARTURE_DATE,
            RETURN_DATE,
            TRIP,
        } = this.props;

        const visible = activeInput === 0 || activeInput === 1;
        return (
            <div>
                <div className="input_group aroundInput">
                    <IntRcln
                        placeholder="YYYYMMDD"
                        label={TRIP === 1 ? '出發日期' : '去程日期'}
                        icon={<IcRcln name="tooldate" />}
                        value={DEPARTURE_DATE.replace(/\-/g, '/')}
                        className={TRIP === 1 ? '' : 'bor-right'}
                        onClick={() => { this.showCalendar(0) }}
                    />
                    {
                        TRIP === 1 ? null : (
                            <IntRcln
                                placeholder="YYYYMMDD"
                                label="回程日期"
                                breakline
                                onClick={() => { this.showCalendar(1) }}
                                value={RETURN_DATE.replace(/\-/g, '/')}
                            />
                        )
                    }

                </div>
                <NvbRslb

                    visible={visible}
                    direction="right"
                >
                    <span className="nvb_rslb_goBack" onClick={this.handleClose}>
                        <IcRcln name="toolbefore" />
                    </span>
                    {
                        visible && (
                            <CyRcmn
                                doubleChoose={TRIP === 1 ? false : true}
                                selectedStartDate={DEPARTURE_DATE}
                                selectedEndDate={TRIP === 1 ? '' : RETURN_DATE}
                                activeInput={activeInput}
                                startMonth={moment().format('YYYY-MM')}
                                endMonth={moment().add(12, 'months').format('YYYY-MM')}
                                startDate="2018-10-15"
                                endDate="2019-08-12"
                                startLabelTitle="入住日期"
                                endLabelTitle="退房日期"
                                ref={e => { this.calendar = e }}
                                onClickConfirm={this.handleConfirm.bind(this)}
                                customDiffTxt={diffDate => {
                                    const showTxt = diffDate + 1;
                                    return '共' + showTxt + '天';
                                }}
                            />
                        )
                    }
                </NvbRslb>
            </div>
        );
    }
}


class Panel extends Component {
    constructor (props) {
        super(props);
        this.state = {
            BOARD_POINT: '', // 出發地
            OFF_POINT: '', // 目的地
            TRIP: 1, // 行程
            DEPARTURE_DATE: '', // 出發日期
            RETURN_DATE: '', // 回程日期
            PASSENGER_NUMBER: '', // 旅客人數
            activeInput: null,
        };
    }
    boardPointChange (selectValue) {
        this.setState({
            BOARD_POINT: selectValue
        });
    }
    offPointChange (selectValue) {
        this.setState({
            OFF_POINT: selectValue
        });
    }
    passengerChange (selectValue) {
        this.setState({
            PASSENGER_NUMBER: selectValue
        });
    }

    tripChange (target) {
        this.setState({
            TRIP: target,
        });
    }
    clearVaule (e) {
        this.setState({
            DEPARTURE_DATE: ''
        });
    }

    roundDate (e) {
        console.log(e);
        this.setState({
            DEPARTURE_DATE: e.startInputValue,
            RETURN_DATE: e.endInputValue
        });
    }
    showCalendar (target) {
        console.log(target);
        this.setState({
            activeInput: target
        });
    }
    hadelChangeDate (start, end, target) {
        this.setState({
            DEPARTURE_DATE: start,
            RETURN_DATE: end,
            activeInput: target
        });
    }
    handleSubmit () {
        let info = {
            'TRIP': this.state.TRIP,
            'BOARD_POINT': this.state.BOARD_POINT,
            'OFF_POINT': this.state.OFF_POINT,
            'DEPARTURE_DATE': this.state.DEPARTURE_DATE,
            'RETURN_DATE': this.state.RETURN_DATE,
            'PASSENGER_NUMBER': this.state.PASSENGER_NUMBER
        };
        console.log('submit');
        arrangeData(info);
    }
    render () {
        const {
            TRIP,
            DEPARTURE_DATE,
            RETURN_DATE,
            activeInput,
        } = this.state;


        return (
            <div className="flight_taiwan">
                <div>
                    <ul className="Rtow">
                        <li className={cx({ 'active': TRIP === 1 })} onClick={() => { this.tripChange(1) }}>單程</li>
                        <li className={cx({ 'active': TRIP === 2 })} onClick={() => { this.tripChange(2) }}>來回</li>
                    </ul>
                </div>
                <div className="padder-v-sm">
                    <StRcln ClassName="m-b-sm" option={Country} placeholder="請選擇" label="出發地" icon={<IcRcln name="planeairplane" />} req breakline whenMouseDown={() => console.log('父層whenMouseDown')} onChangeCallBack={(e) => { this.boardPointChange(e) }} defaultValue={'TSA'} ></StRcln>
                    <StRcln ClassName="m-b-sm" option={Country} placeholder="請選擇" label="目的地" icon={<IcRcln name="toolmap" />} req breakline whenMouseDown={() => console.log('父層whenMouseDown')} onChangeCallBack={(e) => { this.offPointChange(e) }} defaultValue={'MZG'}></StRcln>
                    <MobileCalendar
                        TRIP={TRIP}
                        showCalendar={(e) => { this.showCalendar(e) }}
                        activeInput={activeInput}
                        hadelChangeDate={(start, end, target) => { this.hadelChangeDate(start, end, target) }}
                        DEPARTURE_DATE={DEPARTURE_DATE}
                        RETURN_DATE={RETURN_DATE}
                    ></MobileCalendar>
                    <StRcln ClassName="m-b-sm" option={level} placeholder="請選擇" label="人數" icon={<IcRcln name="toolstaff" />} req breakline whenMouseDown={() => console.log('父層whenMouseDown')} onChangeCallBack={(e) => { this.passengerChange(e) }}></StRcln>
                    <div className="footer">
                        <div className="footerInfo"><IcRcln name="toolif" className="p-r-xs" />注意事項：目前僅華信航空提供線上即時訂購。<a>參考其他航空</a></div>
                        <BtRcnb radius prop="string" className="h-sm m-l-md" lg whenClick={() => { this.handleSubmit() }}>搜尋</BtRcnb>
                    </div>
                </div>
            </div>
        );
    }
}
export default Panel;
