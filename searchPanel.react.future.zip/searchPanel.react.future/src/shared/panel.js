import React, { Component } from 'react';
import Label from '../../magaele/int_rctg/components/Label/Label';
import SingleInputMenu from '../shared/SingleInputMenu/SingleInputMenu';
const inlineStyle = {
    display: 'inline-block',
    marginLeft: 20 + 'px',
    verticalAlign: 'top'
};
const widthCollection = {
    desktop: {
        width: 390 + 'px',
        marginLeft: 20 + 'px'
    }
};
function responsiveStyle () {
    return Object.assign({}, widthCollection.desktop, inlineStyle);
}
// 補字選單分區的callBack
// e.g. "祕魯(PE)__利馬-(LIM)".split('__') = ['祕魯(PE)', '利馬-(LIM)']
//      "泰國(TH)__烏汶-(UBP)__烏汶機場(UBP)".split('__') = ['泰國(TH)', '烏汶-(UBP)', '烏汶機場(UBP)']
const catalogueCallBack = [
    {
        catalogueName: '城市',
        catafilter: (data) => data
    }
];
// 補字選單changeKey
const actRacpChangeKey = (data) => {
    data.forEach((item) => { item.txt = `${item.text}${item.vLinetravelText}` });
    return data;
};

// class Panel extends Component {
//     constructor (props) {
//         super(props);
//         this.state = {
//             query: [], // 需要提交的所有關鍵字：含預設關鍵字以及自行輸入
//             inputValue: '' // 輸入值 = searchKeyWord
//             // isFocus: false, // 是否處於 focus 狀態
//             // showAct: false, // 傳入 custom class
//             // value: 0,
//             // obj: null
//         };
//         this.handleClick = this.handleClick.bind(this);
//         this.handleFocus = this.handleFocus.bind(this);
//         this.handleBlur = this.handleBlur.bind(this);
//         this.setValues = this.setValues.bind(this);
//     }

//     handleClick () {
//         this.setState({
//             test: true
//         });
//     }
//     handleFocus () {
//         this.setState({ isFocus: true, showAct: true });
//     }
//     handleBlur () {
//         this.setState({ isFocus: false, showAct: false });
//     }
//     handleKeyUp () {}

//     setValues (val) {
//         if (typeof val === 'object') {
//             this.setState(val);
//         }
//     }
//     render () {
//         const { query, maxLength, inputValue } = this.state;
//         return (
//             <div style={Object.assign({}, responsiveStyle())}>
//                 <div>
//                     <h3>範例: Single</h3>
//                     <Label
//                         isRequired // 是否為必填欄位
//                         size="lg"
//                         label={'Label'}
//                         iconName={'toolmap'}
//                         subComponent={
//                             <Single
//                                 query={query}
//                                 maxLength={maxLength}
//                                 inputValue={inputValue}
//                                 placeholder={'placeholder'}
//                                 onBlur={this.handleBlur}
//                                 onChange={this.handleChange}
//                                 onClick={this.handleClick}
//                                 onFocus={this.handleFocus}
//                                 onKeyUp={this.handleKeyUp}
//                                 setValues={this.setValues}
//                             />
//                         }
//                     />
//                 </div>
//             </div>
//         );
//     }
// }
class Panel extends Component {
    constructor (props) {
        super(props);
        this.state = {
            selectedData: [], // 需要提交的所有關鍵字：含預設關鍵字以及自行輸入
            inputValue: '' // 輸入值 = searchKeyWord
            // isFocus: false, // 是否處於 focus 狀態
            // showAct: false, // 傳入 custom class
            // value: 0,
            // obj: null
        };
    }
    handleChange=(data) => {
        const { selectedData } = this.state;
        if (selectedData.some(item => data.value === item.value)) {
            let arr = selectedData.filter(item => data.value !== item.value);
            this.setState({ selectedData: arr });
        } else if (selectedData.length < this.selectedDataMax) {
            this.setState({ selectedData: [...selectedData, data] });
        } else {
            return;
        }
    }
    setValue=(obj) => {
        this.setState(prevState => (obj));
    }
    render () {
        const { selectedData } = this.state;
        return (
            <div style={Object.assign({}, responsiveStyle())}>
                <div>
                    <h3>SingleInputMenu</h3>
                    <SingleInputMenu
                        className="SingleInputMenu"
                        // label
                        isRequired // 是否為必填欄位
                        size="lg"
                        label={'出發地'}
                        iconName={'toolmap'}
                        // sub Component
                        fetchPath="../../json/TRS1NEW.json"
                        selectedData={selectedData}
                        max={this.WrapperDtmRclnMax}
                        // int rcln
                        placeholder="請選擇/可輸入目的地、景點關鍵字"
                        // act racp
                        minimumStringQueryLength={2}            // 最少輸入幾個字
                        minimumStringQuery="請輸入至少兩個文字"  // 尚未輸入文字字數到達要求會顯示此字串
                        noMatchText="很抱歉，找不到符合的項目"   // 當沒有配對資料時顯示那些文字
                        // dtm rcln
                        sublabel="找不到選項？請輸入關鍵字查詢"
                        // onChange={this.handleChange}
                        setValue={this.setValue}
                    />

                </div>
            </div>
        );
    }
}
export default Panel;
