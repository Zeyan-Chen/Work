import React from 'react';
import { storiesOf } from '@storybook/react';
// import Mobile from '../src/share/mobile';
// import Pc from '../src/share/pc';
import Shared from '../src/shared/panel';
import SingleChange from '../src/shared/SingleChange';
import Single from '../src/shared/Single';

storiesOf('共用', module).add('Share', () => (
    <div>
        <SingleChange />
        <h3>Single</h3>
        <Single />
        <Shared />
    </div>
));
