import React, { Component } from 'react';
import DtmRcln from '../../../magaele/dtm_rcln';
import IntRcln from '../../../magaele/int_rcln';


class dtm_rcln extends Component {
    constructor (props) {
        super(props);
        this.state = {
            open: false,
            selectedData: [],
            inputValue: ''
        };
        this.openMenu = this.openMenu.bind(this);
        this.closeMenu = this.closeMenu.bind(this);
        this.handleMouseDown = this.handleMouseDown.bind(this);
        this.handleMouseUp = this.handleMouseUp.bind(this);
        this.sourceData = null;
        this.dom = null;
    }
    openMenu () {
        this.setState({ open: true });
    }
    closeMenu () {
        if (this.isMouseDown) return;
        this.setState({ open: false });
    }
    handleMouseDown () {
        this.isMouseDown = true;
    }
    handleMouseUp () {
        this.isMouseDown = false;
    }
    render () {
        const showValue = this.state.selectedData.map((v, i) => v.txt);

        return (
            <div className="dtm_rcln_wrap"
                ref={e => { this.dom = e; console.log(this.dom); }}
            >
                <IntRcln
                    placeholder="請輸入/選擇目的地"
                    onFocus={this.openMenu}
                    onBlur={this.closeMenu}
                    onChange={(e) => this.setState({ inputValue: e.target.value })}
                    value={this.state.inputValue}
                    color="blue"
                />
                <DtmRcln
                    onBlur={this.closeMenu}
                    onMouseDown={this.handleMouseDown}
                    onMouseUp={this.handleMouseUp}
                    open={this.state.open}
                    onChange={data => {
                        this.setState({
                            selectedData: data
                        });
                    }}
                    whenClose={() => {
                        this.setState({
                            open: false
                        });
                    }}
                    sourceData={this.sourceData}
                    allData={this.state.allData}
                    selectedData={this.state.selectedData}
                    label="最多可選擇5個目的地"
                    lineOrder={['_6', '_5', '_7', '_3', '_1', '_4', '_2', '_9']}
                    levelKey={['vLine', 'vLinetravel', 'vLinewebarea']}
                    fetchPath="../json/TRS1NEWDOM.js"
                    positionDOM={this.dom}
                    // noTabItem
                    // noTab
                    inline
                    customSourceData={(data) => {
                        let newData = data;
                        newData.vLine = {
                            '_6': '東北亞',
                            '_5': '大陸港澳',
                            '_7': '東南亞',
                            '_3': '歐洲',
                            '_1': '美洲',
                            '_4': '亞非',
                            '_2': '大洋洲',
                            '_9': '台灣'
                        };
                        return newData;
                    }}
                />
            </div>
        );
    }
}

export default dtm_rcln;