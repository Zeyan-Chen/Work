import React, { Component } from 'react';

class Panel extends Component {
    render () {
        return (
            <div>團體Mobile面板</div>
        );
    }
}

export default Panel;