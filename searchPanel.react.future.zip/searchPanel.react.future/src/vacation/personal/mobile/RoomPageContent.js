import React, { PureComponent } from 'react';
import IntGpct from '../../../../magaele/int_gpct';
import StRcln from '../../../../magaele/st_rcln';
import IntRcln from '../../../../magaele/int_rcln';
import BtRcnb from '../../../../magaele/bt_rcnb';
import { isArray } from 'util';

// 從間數人數物件轉字串
function calcShowText (roomList) {
    // 間數
    const roomCount = roomList.length;
    let str = `共${roomCount}間，`;
    for (let i = 0; i < roomList.length; i++) {
        const a = roomList[i].adult; // 每間房大人人數
        const b = roomList[i].childrenWithBed.length; // 每間房小孩佔床人數
        const c = roomList[i].childrenNoBed.length; // 每間房小孩不佔床人數
        const total = a + b + c;
        str += `${total}、`;
    }
    str = str.replace(/\、$/g, '人');
    return str;
}

// 間數options
const roomCount = [
    {
        text: '共1間',
        value: 1,
    },
    {
        text: '共2間',
        value: 2,
    },
    {
        text: '共3間',
        value: 3,
    },
    {
        text: '共4間',
        value: 4,
    },
    {
        text: '共5間',
        value: 5,
    },
    {
        text: '共6間',
        value: 6,
    },
    {
        text: '共7間',
        value: 7,
    }
];

const ChildrenAgeSelect = ({
    onchange,
}) => (
    <label className="children_age_select">
        <select onChange={onchange}>
            <option value="0">0歲</option>
            <option value="1">1歲</option>
            <option value="2">2歲</option>
            <option value="3">3歲</option>
            <option value="4">4歲</option>
            <option value="5">5歲</option>
            <option value="6">6歲</option>
            <option value="7">7歲</option>
            <option value="8">8歲</option>
            <option value="9">9歲</option>
            <option value="10">10歲</option>
            <option value="11">11歲</option>
            <option value="12">12歲</option>
        </select>
    </label>
);

const ChildAgeSection = (props) => {
    const {
        ageArray,
        onChange,
        roomCount,
        target,
    } = props;
    return (
        <div className="children_ages_section m-t-sm">
            <span className="row_title">小孩年齡</span>
            <div className="age_select_section">
                {
                    ageArray.map((v, i) => (
                        <ChildrenAgeSelect
                            key={i}
                            onchange={e => {
                                onChange(roomCount, target, i, e.target.value);
                            }}
                            defaultValue={v}
                        />
                    ))
                }
            </div>
        </div>
    );
};

const RoomLitSection = (props) => {
    const {
        roomCount,
        adult,
        childrenWithBed,
        childrenNoBed,
        onClickAdd, // 點選增加人數
        onClickMinus, // 點選減少人數
        onChangeChildAge, // 小孩年齡change
    } = props;

    const childBedCount = childrenWithBed.length;
    const childNoBedCount = childrenNoBed.length;

    return (
        <section className="room_list_section">
            <h4 className="room_count_title">{`第${roomCount + 1}間`}</h4>
            <div className="room_list_row">
                <span className="row_title">成人</span>
                <IntGpct
                    max={8}
                    min={1}
                    count={adult}
                    btnClassMinus="ic_rcln toolcancelb"
                    btnClassAdd="ic_rcln tooladdb"
                    onClickAdd={() => { onClickAdd(roomCount, 'adult') }}
                    onClickMinus={() => { onClickMinus(roomCount, 'adult') }}
                />
            </div>
            <div className="room_list_row">
                <div>
                    <span className="row_title">小孩佔床</span>
                    <IntGpct
                        max={3}
                        min={0}
                        count={childBedCount}
                        btnClassMinus="ic_rcln toolcancelb"
                        btnClassAdd="ic_rcln tooladdb"
                        onClickAdd={() => { onClickAdd(roomCount, 'childrenWithBed') }}
                        onClickMinus={() => { onClickMinus(roomCount, 'childrenWithBed') }}
                    />
                </div>
                {
                    childBedCount > 0
                        ?
                        (
                            <ChildAgeSection
                                ageArray={childrenWithBed}
                                onChange={onChangeChildAge}
                                roomCount={roomCount}
                                target="childrenWithBed"
                            />
                        )
                        :
                        null
                }
            </div>
            <div className="room_list_row">
                <div>
                    <span className="row_title">小孩不佔床</span>
                    <IntGpct
                        max={3}
                        min={0}
                        count={childNoBedCount}
                        btnClassMinus="ic_rcln toolcancelb"
                        btnClassAdd="ic_rcln tooladdb"
                        onClickAdd={() => { onClickAdd(roomCount, 'childrenNoBed') }}
                        onClickMinus={() => { onClickMinus(roomCount, 'childrenNoBed') }}
                    />
                </div>
                {
                    childNoBedCount > 0
                        ?
                        (
                            <ChildAgeSection
                                ageArray={childrenNoBed}
                                onChange={onChangeChildAge}
                                roomCount={roomCount}
                                target="childrenNoBed"
                            />
                        )
                        :
                        null
                }
            </div>
        </section>
    );
};

class RoomPageContent extends PureComponent {
    state = {
        roomList: [
            {
                adult: 1,
                childrenWithBed: [],
                childrenNoBed: []
            },
            {
                adult: 1,
                childrenWithBed: [],
                childrenNoBed: []
            }
        ],
        maxPeople: 8, // 最大人數8人
        maxChild: 3, // 小孩佔床+不佔床 最多3人
        childForSingleAdult: 2, // 一位大人最多2位小孩
        minAdult: 1, // 每間房最少1位大人
        inputText: '',
    };

    calcPeopleInfo () {
        // 計算人數資訊 return value [總人數, 總成人數, 總小孩佔床人數, 總小孩不佔床人數]
        const { roomList } = this.state;
        let total = 0;
        let adult = 0;
        let childrenWithBed = 0;
        let childrenNoBed = 0;
        for (let i = 0; i < roomList.length; i++) {
            const a = roomList[i].adult; // 每間房大人人數
            const b = roomList[i].childrenWithBed.length; // 每間房小孩佔床人數
            const c = roomList[i].childrenNoBed.length; // 每間房小孩不佔床人數
            adult += a;
            childrenWithBed += b;
            childrenNoBed += c;
            total = total + a + b + c;
        }
        return [total, adult, childrenWithBed, childrenNoBed];
    }

    changeRoomCount = (value) => {
        const {
            roomList,
        } = this.state;
        const count = Number(value);

        const dataTemplate = {
            adult: 1,
            childrenWithBed: [],
            childrenNoBed: []
        };

        if (count === roomList.length) return;

        const dataArray = [];

        for (let i = 0; i < count; i++) {
            dataArray.push(dataTemplate);
        }

        const inputText = calcShowText(dataArray);

        this.setState(prevState => {
            return {
                ...prevState,
                inputText,
                roomList: dataArray,
            };
        });
    }

    onClickAdd = (roomCount, target) => {
        const {
            maxPeople,
            maxChild,
            childForSingleAdult,
        } = this.state;

        const [
            total,
            adultNum,
            childBedNum,
            childNoBedNum,
        ] = this.calcPeopleInfo();

        // 超過最大人數
        if (total + 1 > maxPeople) return;

        // 如果增加的是小孩人數
        if (target === 'childrenWithBed' || target === 'childrenNoBed') {
            const newCount = childBedNum + childNoBedNum + 1;
            // 一個大人最多帶兩位小孩
            if (adultNum === 1 && newCount > childForSingleAdult) return;
            // 小孩總人數不能超過3
            if (newCount > maxChild) return;
        }

        this.setState(prevState => {
            const roomList = JSON.parse(JSON.stringify(prevState.roomList));
            let t = roomList[roomCount][target];

            if (isArray(t)) {
                // 是陣列表示增加的是小孩人數
                t.push(0);
            } else {
                t = t + 1;
            }

            roomList[roomCount][target] = t;

            const inputText = calcShowText(roomList);

            return {
                ...prevState,
                roomList,
                inputText,
            };
        });
    }

    onClickMinus = (roomCount, target) => {
        const {
            minAdult,
        } = this.state;

        let roomList = JSON.parse(JSON.stringify(this.state.roomList));
        let t = roomList[roomCount][target];

        if (target === 'adult') {
            // 已經是最少大人數
            if (t === minAdult) return;

            // 減一位大人
            roomList[roomCount][target] = t - 1;

            // 大人減少了就把小孩人數全部歸0
            roomList = roomList.map(v => ({
                adult: v.adult,
                childrenWithBed: [],
                childrenNoBed: [],
            }));

        } else {
            // 如果小孩人數已經為0
            if (t.length === 0) return;

            // 減掉最後一個小孩
            t.pop();
        }

        const inputText = calcShowText(roomList);

        this.setState(prevState => ({
            ...prevState,
            roomList,
            inputText,
        }));
    }

    onChangeChildAge = (roomCount, target, targetIndex, value) => {
        const roomList = JSON.parse(JSON.stringify(this.state.roomList));
        const val = Number(value);

        roomList[roomCount][target][targetIndex] = val;

        this.setState(prevState => ({
            ...prevState,
            roomList,
        }));
    }

    render () {
        const {
            roomList,
            inputText,
        } = this.state;

        const {
            onClickConfirm,
        } = this.props;

        return (
            <div className="nvb_content">
                <header>
                    <h3 className="txt-center m-b-md">間數/人數</h3>
                    <div className="search_input">
                        <IntRcln
                            placeholder="共N間，N人"
                            readOnly
                            value={inputText}
                        />
                        <BtRcnb radius whenClick={() => {
                            onClickConfirm(this.state);
                        }}>
                            確定
                        </BtRcnb>
                    </div>
                </header>
                <div className="page_content">
                    <StRcln
                        option={roomCount}
                        placeholder="請選擇"
                        label="間數:"
                        defaultValue={roomList.length}
                        onChangeCallBack={this.changeRoomCount}
                        ClassName="m-b-sm"
                    />
                    {
                        roomList.map((v, i) => (
                            <RoomLitSection
                                key={i}
                                roomCount={i}
                                adult={v.adult}
                                childrenWithBed={v.childrenWithBed}
                                childrenNoBed={v.childrenNoBed}
                                onClickAdd={this.onClickAdd} // 點選增加人數
                                onClickMinus={this.onClickMinus} // 點選減少人數
                                onChangeChildAge={this.onChangeChildAge} // 小孩年齡change
                            />
                        ))
                    }
                    <p className="txt_green">一筆訂單總人數若超過8位，請分兩張單位訂購。</p>
                    <p className="txt_green">一位大人最多只能帶2名小孩或1名小孩+1名嬰兒</p>
                    <p className="txt_green">（小孩定義：年滿2歲(含)以上未滿12歲。嬰兒定義：未滿2歲。)</p>
                </div>
            </div>
        );
    }
}

export default RoomPageContent;