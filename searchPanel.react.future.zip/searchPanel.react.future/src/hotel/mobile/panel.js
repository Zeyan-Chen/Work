import React, { Component } from 'react';
import classNames from 'classnames';
import styles from './css.scss';
import IntRcln from '../../../magaele/int_rcln';
import IcRcln from '../../../magaele/ic_rcln';
import StRcln from '../../../magaele/st_rcln';
import DtmRcfr from '../../../magaele/dtm_rcfr';
import CyRcmn from '../../../magaele/cy_rcmn';
import NvbRslb from '../../../magaele/nvb_rslb';
import BtRcnb from '../../../magaele/bt_rcnb';
import IntGpct from '../../../magaele/int_gpct';
import RoomPageContent from './RoomPageContent';
import CrRcln from '../../../magaele/cr_rcln';


// import ActRacp from '../../../magaele/act_racp/components/Module';
// import SearchInput from '../../../magaele/act_racp/components/SearchInput';


const NvbGoBack = ({
    onClick,
}) => (
    <span className="nvb_rslb_goBack" onClick={onClick}>
        <IcRcln name="toolbefore" />
    </span>
);

class Panel extends Component {
    constructor (props) {
        super(props);
        this.state = {
            Destination: {},
            // Code: '',
            // Kind: '',
            // Txt: '',
            Rooms: [],
            CheckIn: '',
            CheckOut: '',
            Filter: {
                Allotment: '0'
            },
            activeInput: null,
            selectedData: [],
            roomListInput: '',
            totleNights: 0
        };
    }
    showCalendar (target) {
        this.setState(prevState => ({
            ...prevState,
            activeInput: target,
        }));
    }
    showNvbPage (target) {
        this.setState(prevState => ({
            ...prevState,
            activeInput: target,
        }));
    }
    handleClose = () => {
        this.setState({
            activeInput: null,
        });
    }
    handleConfirmRoom = () => {
        this.setState({
            activeInput: null,
        });
    }
    handleConfirmBookingDate = () => {
        const {
            selectedStartDate,
            selectedEndDate,
        } = this.calendar.state;
        this.diffDate(selectedStartDate, selectedEndDate);
        this.setState(prevState => ({
            ...prevState,
            CheckIn: selectedStartDate,
            CheckOut: selectedEndDate,
            activeInput: null,
        }));
    }
    onClickItem = (data) => {
        this.setState(prevState => ({
            selectedData: [data],
        }));
    }
    peopleSum = (pageState) => {
        const {
            inputText: roomListInput,
            Rooms
        } = pageState;
        this.setState({
            roomListInput,
            Rooms
        });
    }
    diffDate (selectedStartDate, selectedEndDate) {
        if (!selectedStartDate.length || !selectedEndDate.length) return '';
        const d1 = new Date(selectedStartDate).getTime();
        const d2 = new Date(selectedEndDate).getTime();
        const dayDiff = (d2 - d1) / (1000 * 3600 * 24);
        this.setState({
            totleNights: dayDiff
        });
    }
    handleAllotment = (boolean) => {
        const Filter = JSON.parse(JSON.stringify(this.state.Filter));
        Filter.Allotment = boolean ? '1' : '0';
        this.setState({
            Filter
        });
    }

    render () {
        const {
            CheckIn,
            CheckOut,
            activeInput,
            roomListInput,
            totleNights
        } = this.state;
        const classes = classNames.bind(styles)('hotelsRectM');
        const selectedData = this.state.selectedData;
        const txt = (selectedData.length > 0) ? selectedData[0].text : '';
        const selected = selectedData.map(v => v.value);
        const showCalendarPage = activeInput === 0 || activeInput === 1;
        const shwoDestinationsPage = activeInput === 'destinationlist';
        const showRoomPage = activeInput === 'roomlist';
        return (
            <div className={classes}>
                <div className={`${classes}_hotelCont`}>
                    <div className="destination">
                        <IntRcln
                            placeholder="目的地、地標、區域、飯店名稱"
                            label="目的地"
                            icon={<IcRcln name="toolmap" />}
                            value={txt}
                            onClearValue={value => {
                                console.log(value);
                            }}
                            onClick={() => { this.showNvbPage('destinationlist') }}
                        />
                        {/* <div className={`dtmRcfr ${this.state.focusDestinationState ? 'show' : ''}`}>
                            <button className="close_btn" onClick={this.closeDestination}>X</button>
                            <DtmRcfr
                                levelKey={['inTaiwan', 'vLine', 'vCountry', 'vCity']}
                                onClickItem={this.onClickItem}
                                dataResouce="./json/hotelMenu.json"
                                replaceRegular={/[a-zA-Z\(\)\s]/g}
                                selectedData={selected}
                            />
                        </div> */}
                    </div>
                    <div className="input_group">
                        <IntRcln
                            placeholder="YYYY/MM/DD"
                            label="住房期間"
                            icon={<IcRcln name="tooldate" />}
                            breakline
                            readOnly
                            request
                            onClick={() => { this.showCalendar(0) }}
                            value={CheckIn.replace(/\-/g, '/')}
                        />
                        <span className="cal_icon">~</span>
                        <IntRcln
                            placeholder="YYYY/MM/DD"
                            breakline
                            readOnly
                            onClick={() => { this.showCalendar(1) }}
                            value={CheckOut.replace(/\-/g, '/')}
                        />
                        {
                            totleNights > 0 ? (
                                <span className="nights">{
                                    `共${totleNights}晚`
                                }</span>
                            ) : null
                        }
                    </div>
                    <IntRcln
                        placeholder="共1間，2位大人、0位小孩"
                        value={roomListInput}
                        label="間數/人數"
                        breakline
                        readOnly
                        icon={<IcRcln name="toolmember" />}
                        className="m-b-sm"
                        onClick={() => { this.showNvbPage('roomlist') }}
                    />
                    <div><CrRcln type="checkbox" whenChange={this.handleAllotment} textContent="顯示可立即確認訂房"></CrRcln></div>

                    <NvbRslb
                        visible={shwoDestinationsPage}
                        direction="right"
                    >
                        <NvbGoBack onClick={this.handleClose} />
                        <DtmRcfr
                            levelKey={['inTaiwan', 'vLine', 'vCountry', 'vCity']}
                            onClickItem={this.onClickItem}
                            dataResouce="./json/hotelMenu.json"
                            replaceRegular={/[a-zA-Z\(\)\s]/g}
                            selectedData={selected}
                        />
                    </NvbRslb>

                    <NvbRslb
                        visible={showCalendarPage}
                        direction="right"
                        className="hotelsRectM-calendar"
                    >
                        <NvbGoBack onClick={this.handleClose} />
                        {
                            showCalendarPage && (
                                <CyRcmn
                                    doubleChoose
                                    selectedStartDate={CheckIn}
                                    selectedEndDate={CheckOut}
                                    activeInput={activeInput}
                                    startLabelTitle="入住日期"
                                    endLabelTitle="退房日期"
                                    ref={e => { this.calendar = e }}
                                    onClickConfirm={this.handleConfirmBookingDate}
                                />
                            )
                        }
                    </NvbRslb>

                    <NvbRslb className="hotelsRectM-roomPage" visible={showRoomPage} direction="right">
                        <NvbGoBack onClick={this.handleClose} />
                        <div className="nvb_content">
                            <header className="hotelsRectM-header">
                                <h3 className="txt-center m-b-md">間數/人數</h3>
                                <div className="search_input">
                                    <IntRcln
                                        placeholder="共1間，2位大人、0位小孩"
                                        value={roomListInput}
                                        readOnly
                                    />
                                    <BtRcnb radius whenClick={this.handleConfirmRoom} >確定</BtRcnb>
                                </div>
                            </header>
                            <div className="hotelsRectM-roomList">
                                <RoomPageContent changeSum={this.peopleSum} />
                                <p className="psTxt">※單次訂購提供相同房型，相同房型不同入住人數依選購的專案售價。</p>
                            </div>
                        </div>
                    </NvbRslb>
                </div>
            </div>
        );
    }
}

export default Panel;